import { ViewModuleIcon, Edit1Icon, LayersIcon } from 'tdesign-icons-vue';
import Layout from '@/layouts/index.vue';

export default [
  {
    path: '/create',
    name: 'create',
    component: Layout,
    redirect: '/create/base',
    meta: { title: '创建实验', icon:'component-space', single:true },
    children: [
      {
        path: 'base',
        name: 'CreateBase',
        component: () => import('@/pages/create/base/index.vue'),
        meta: { title: '创建实验' },
      },
      {
        path: 'check',
        name: 'CreateCheck',
        component: () => import('@/pages/create/detail/check.vue'),
        meta: { title: '创建死锁检测实验' },
      },
      {
        path: 'solve',
        name: 'CreateSolve',
        component: () => import('@/pages/create/detail/solve.vue'),
        meta: { title: '创建死锁解决实验' },
      },
    ],
  },
  {
    path: '/demonstrate',
    name: 'demonstrate',
    component: Layout,
    redirect: '/demonstrate/base',
    meta: { title: '演示实验', icon: 'history', single:true },
    children: [
      {
        path: 'base/:type',
        name: 'DemonstrateBase',
        component: () => import('@/pages/demonstrate/base/index.vue'),
        meta: { title: '演示实验' },
      },
    ],
  },
  {
    path: '/introduce',
    name: 'introduce',
    component: Layout,
    redirect: '/introduce/base',
    meta: { title: '平台介绍', icon: 'control-platform', single:true },
    children: [
      {
        path: 'base',
        name: 'IntroduceBase',
        component: () => import('@/pages/introduce/base/index.vue'),
        meta: { title: '平台介绍' },
      },
    ],
  },
  {
    path: '/analyze',
    name: 'analyze',
    component: Layout,
    redirect: '/analyze/base',
    meta: { title: '实验分析', icon: 'mail', single:true },
    children: [
      {
        path: 'base',
        name: 'AnalyzeBase',
        component: () => import('@/pages/analyze/base/index.vue'),
        meta: { title: '实验分析' },
      },
    ],
  },

];
