<template>
  <div class="background">
    <div class="create-check-title-container">
      <p>死锁解决实验</p>
      <t-button @click="saveTestData"> 点击使用测试数据</t-button>
    </div>
    <div class="create-resource-container">
      <div class="create-resource-title-container">
        <div class="create-resource-title">
          <div class="green-stick"></div>
          创建可分配资源
        </div>
        <div v-if="resourcesCheck" class="create-resource-checked-container">
          <div v-for="(resource, index) in resources" class="create-resource-checked">
            <p style="width: 3em">资源{{ String.fromCharCode(65 + index) }}</p>
            <p>系统中共有{{ resource.count }}个</p>
            <p style="width: 6em"></p>
          </div>
        </div>
      </div>

      <div v-if="!resourcesCheck" class="create-resource-tabs-container">
        <div
          v-for="(resource, index) in resources"
          :key="resource.name" v-if="resource.exist"
          class="create-resource-tabs"
        >
          <div class="close-circle">
            <div class="close-X" @click="handleDel(index)">×</div>
          </div>
          <p class="resource-name">资源{{ String.fromCharCode(65 + index) }}</p>
          <t-input-number
            class="resource-num-input"
            min="0"
            theme="normal"
            :onValidate="inputError()"
            v-model="resource.count"
            label="系统中共有："
            type="number"
            suffix="个"
          />
          <div></div>
        </div>
      </div>

      <div v-else class="create-resource-title-container">
        <div class="create-resource-title">
          <div class="green-stick"></div>
          创建进程
        </div>
      </div>

      <div v-if="resourcesCheck" class="create-resource-tabs-container">
        <div v-for="(process, index) in processes" :key="process.name" v-if="process.exist" class="create-process-tabs">
          <div class="close-circle">
            <div class="close-X" @click="handleDel(index)">×</div>
          </div>
          <p class="process-name">进程{{ index + 1 }}</p>

          <div class="process-input-container">
            <t-input-number
              v-if="showABC>0"
              class="resource-num-input"
              min="0"
              theme="normal"
              :onValidate="inputError()"
              v-model="process.allocation[0]"
              label="已持有资源A的数量："
              type="number"
            />
            <t-input-number
              v-if="showABC>1"
              class="resource-num-input"
              min="0"
              theme="normal"
              :onValidate="inputError()"
              v-model="process.allocation[1]"
              label="已持有资源B的数量："
              type="number"
            />
            <t-input-number
              v-if="showABC>2"
              class="resource-num-input"
              min="0"
              theme="normal"
              :onValidate="inputError()"
              v-model="process.allocation[2]"
              label="已持有资源C的数量："
              type="number"
            />
          </div>

          <div class="process-input-container">
            <t-input-number
              v-if="showABC>0"
              class="resource-num-input"
              :min="process.allocation[0]"
              theme="normal"
              :onValidate="inputError()"
              v-model="process.max_requirements[0]"
              label="资源A的待分配需求量："
              type="number"
            />
            <t-input-number
              v-if="showABC>1"
              class="resource-num-input"
              :min="process.allocation[1]"
              theme="normal"
              :onValidate="inputError()"
              v-model="process.max_requirements[1]"
              label="资源B的待分配需求量："
              type="number"
            />
            <t-input-number
              v-if="showABC>2"
              class="resource-num-input"
              :min="process.allocation[2]"
              theme="normal"
              :onValidate="inputError()"
              v-model="process.max_requirements[2]"
              label="资源C的待分配需求量："
              type="number"
            />
          </div>

          <div></div>
        </div>
      </div>

      <div class="add-container">
        <div style="width: 3em"></div>
        <div class="add-circle">
          <div class="add-plus" @click="handleAdd">+</div>
        </div>
        <div v-if="resources.length != 0" class="check-button" @click="handleCheck">
          <t-icon name="check"></t-icon>
        </div>
        <div v-else style="width: 3em"></div>
      </div>
    </div>
  </div>

</template>

<script>
export default {
  data() {
    return {
      resources: [],
      alphabetIndex: 0,
      processes: [],
      processIndex: 0,
      resourcesCheck: false,
      showABC: 0,
      testData: {
        resources: [
          // 撤销测试数据
          {
            name: 'A',
            count: 10,
            exist: true,
          },
          {
            name: 'B',
            count: 8,
            exist: true,
          },
          {
            name: 'C',
            count: 7,
            exist: true,
          },
        ],
        processes: [
          {
            name: 1,
            count: 0,
            allocation: [3, 2, 2],
            max_requirements: [5, 0,0 ],
            exist: true,
          },
          {
            name: 2,
            count: 0,
            allocation: [2, 4, 3],
            max_requirements: [2, 2, 4],
            exist: true,
          },
          {
            name: 3,
            count: 0,
            allocation: [3, 2, 2],
            max_requirements: [6, 1, 4],
            exist: true,
          },
        ],
        mark:'cancel'
      },
      testData_need: {// 回滚测试数据
        resources: [
          // 撤销测试数据
          {
            name: 'A',
            count: 10,
            exist: true,
          },
          {
            name: 'B',
            count: 8,
            exist: true,
          },
          {
            name: 'C',
            count: 7,
            exist: true,
          },
        ],
        processes: [
          {
            name: 1,
            count: 0,
            allocation: [3, 2, 2],
            max_requirements: [5, 0,0 ],
            exist: true,
          },
          {
            name: 2,
            count: 0,
            allocation: [2, 4, 3],
            max_requirements: [2, 2, 4],
            exist: true,
          },
          {
            name: 3,
            count: 0,
            allocation: [3, 2, 2],
            max_requirements: [6, 1, 4],
            exist: true,
          },
        ],
        mark:'roll'
      },
    };
  },
  // computed: {
  //   filteredResources() {
  //     return this.resources.filter(resource => resource.exist);
  //   }
  // },
  methods: {
    inputError() {
      // return (context) => {
      //   if (context.error === 'exceed-maximum') {
      //     this.$message.warning('输入值超出最大值');
      //   } else if (context.error === 'below-minimum') {
      //     this.$message.warning('输入值小于最小值');
      //   } else {
      //     console.log('校验通过。');
      //   }
      // };
    },
    saveTestData() {
      sessionStorage.setItem('data', JSON.stringify(this.testData));
      sessionStorage.setItem('data_need', JSON.stringify(this.testData_need));
      console.log(sessionStorage.getItem('data'));
      this.$message.success('使用测试数据成功！');
      this.$router.push({name: 'DemonstrateBase', params: {type: 'solve'}});
    },
    handleAdd() {
      if (!this.resourcesCheck) {
        if (this.resources.length != 3) {
          const name = String.fromCharCode(65 + this.alphabetIndex);
          this.resources.push({name, count: 0, exist: true});
          this.alphabetIndex = (this.alphabetIndex + 1) % 26;
        } else {
          // this.resourcesCheck = true;
          this.$message.warning('只允许创建不超过3个资源！点击√以确定');

        }
      } else {
        if (this.processes.length != 3) {
          const name = ++this.processIndex;
          if (this.showABC > 2) {
            this.processes.push({name, count: 0, allocation: [0, 0, 0], max_requirements: [0, 0, 0], exist: true});
          } else if (this.showABC > 1) {
            this.processes.push({name, count: 0, allocation: [0, 0], max_requirements: [0, 0], exist: true});
          } else if (this.showABC > 0) {
            this.processes.push({name, count: 0, allocation: [0], max_requirements: [0], exist: true});
          }

        } else {
          this.$message.warning('只允许创建不超过3个进程！');
        }
      }
    },
    handleDel(index) {
      if (!this.resourcesCheck) {
        this.resources.splice(index, 1);
      } else {
        this.processes.splice(index, 1);
      }
    },
    handleCheck() {
      if (!this.resourcesCheck) {
        if (this.resources.length > 3) {
          this.$message.warning('只允许创建不超过3个资源！');
          return;
        }
        this.resourcesCheck = true;
        this.showABC = this.resources.length;
      } else {
        // this.processes.splice(index, 1);
        if (this.processes.length > 3) {
          this.$message.warning('只允许创建不超过3个进程！');
          return;
        }
        this.$router.push({name: 'DemonstrateBase', params: {type: 'solve'}});
        const resources = this.resources;
        const processes = this.processes;
        const data = {resources, processes};
        sessionStorage.setItem('data', JSON.stringify(data));
        // console.log(sessionStorage.getItem('data'))

        let data1 = JSON.parse(JSON.stringify(data));

        //存储 还需要的
        // 遍历processes数组
        for (let i = 0; i < data1.processes.length; i++) {
          let process = data1.processes[i];
          // 确保allocation和max_requirements数组长度相同
          if (process.allocation.length === process.max_requirements.length) {
            // 对应元素相减并重新赋值给max_requirements
            for (let j = 0; j < process.max_requirements.length; j++) {
              process.max_requirements[j] = process.max_requirements[j] - process.allocation[j];
            }
          } else {
            // 如果数组长度不一致，可以抛出错误或者根据需要处理
            console.error(
              'Error: Allocation and max_requirements arrays have different lengths for process ' + process.name,
            );
          }
        }
        sessionStorage.setItem('data_need', JSON.stringify(data1));
      }
    },
  },
};
</script>


<style scoped>
.create-check-title-container {
  display: flex;
  justify-content: space-between;
  margin-bottom: -20px;
}

.create-resource-title-container {
  margin-top: 2em;
  padding: 10px;
  background-color: white;
  border-radius: 3px;
}

.create-resource-title {
  align-items: center;
  display: flex;
}

.green-stick {
  height: 1.3em;
  width: 0.3em;
  margin-right: 10px;
  background-color: #6dcca3;
}

.create-resource-checked-container {
}

.create-resource-checked {
  display: flex;
  margin-left: 2em;
  margin-top: 0.8em;
  justify-content: space-between;
}

.add-circle {
  width: 3em;
  height: 3em;
  border-radius: 50%;
  background-color: #75d12e;
  display: flex;
  justify-content: center;
  align-items: center;
}

.add-plus {
  user-select: none;
  font-weight: lighter;
  font-size: 3em;
  color: white;
  margin-top: -0.15em;
}

.add-container {
  padding: 20px;
  display: flex;

  justify-content: space-between;
  align-items: center;
}

.check-button {
  font-size: 3em;
  color: orange;
  float: right;
}

.create-resource-tabs {
  height: 40px;
  margin-top: 15px;
  background-color: white;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.close-circle {
  position: absolute;
  left: -0.75em;
  top: -0.7em;
  width: 1.5em;
  height: 1.5em;
  border-radius: 50%;
  background-color: #e12a1b;
  display: flex;
  justify-content: center;
  align-items: center;
}

.close-X {
  user-select: none;
  font-weight: lighter;
  font-size: 1.5em;
  color: white;
  margin-top: -0.15em;
}

.resource-name {
  margin-left: 30px;
}

.resource-num-input {
  width: 200px;
  margin-left: -80px;
}

.create-process-tabs {
  padding: 10px;
  height: 11em;
  margin-top: 15px;
  background-color: white;
  position: relative;
  /* display: flex;
  align-items: center;
  justify-content: space-between; */
}

.process-name {
  margin-left: 30px;
}

.process-input-container {
  margin-top: 1em;
  display: flex;
  justify-content: space-around;
}

/* .process-input-container-2{
    display: flex;
    justify-content: space-around;
} */
</style>
