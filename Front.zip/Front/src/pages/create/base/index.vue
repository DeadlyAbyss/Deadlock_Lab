<template>
  <div class="create-container">
    <div class="card-container">
      <t-card class="card-left" @click.native="createCheck" :bordered="false" hover-shadow>
        <div class="plus-left">
          <div class="circle">
            <div class="plus">+</div>
          </div>
        </div>
        <div class="lab-container">死锁检测实验</div>
      </t-card>

      <t-card class="card-right" @click.native="createSolve" :bordered="false" hover-shadow>
        <div class="plus-right">
          <div class="circle">
            <div class="plus">+</div>
          </div>
        </div>
        <div class="lab-container">死锁解决实验</div>
      </t-card>
    </div>
    <div>
      <div class="desc-container">
        <div class="desc-detail">
          <t-icon name="chat-poll" size="1.5em" />
          死锁检测实验：系统运行时，学生可以执行特定死锁检测算法，并实时检测系统状态，提示是否存在死锁。
        </div>
        <div class="desc-detail">
          <t-icon name="chat-poll" size="1.5em" />
          死锁解决实验：发生死锁时，学生可以执行特定死锁解决算法，提供不同的死锁解决算法选项，并展示解决方案的效果。
        </div>
      </div>
      <t-alert message="消息面板" />
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {
    createCheck() {
      this.$router.push('/create/check');
    },
    createSolve() {
      this.$router.push('/create/solve');
    },
  },
};
</script>

<style scoped>
* {
  user-select: none;
}
.create-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
}
.card-container {
  display: flex;
  justify-content: space-around;
  padding: 20px;
}
.card-left {
  width: 300px;
  height: 300px;
  border-radius: 80px 0 0 0;
  font-size: 2em;
}
.card-right {
  width: 300px;
  height: 300px;
  border-radius: 0 40px 0 0;
  font-size: 2em;
}
.circle {
  width: 2em;
  height: 2em;
  border-radius: 50%;
  background-color: #95ceae;
  display: flex;
  justify-content: center;
  align-items: center;
}

.plus {
  font-weight: lighter;
  font-size: 2em;
  color: white;
  margin-top: -0.15em;
}
.plus-right {
  margin-right: 1em;
  margin-top: 1em;
  float: right;
}
.plus-left {
  margin-left: 1em;
  margin-top: 1em;
  float: left;
}
.lab-container {
  text-align: center;
  margin-top: 5em;
}
.desc-container {
  margin-top: 50px;
  width: 100%;
  height: 200px;
  background-color: white;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
}

.desc-detail {
  margin-left: 30px;
  font-size: 1.3em;
}
</style>
