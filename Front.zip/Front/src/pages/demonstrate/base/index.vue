<template>
  <div class="demo-container">

    <div v-show="!showResource" class="demo-left-container">
      <div id="main_banker" class="display-container">
        <div></div>
      </div>
      <div class="button-container">
        <t-button shape="round" size="large" theme="success">确定</t-button>
        <t-button @click="graph_continue_banker()" shape="round" size="large" theme="warning">继续</t-button>
        <t-button shape="round" size="large" theme="danger">结束</t-button>
      </div>
    </div>
    <div v-show="showResource" class="demo-left-container">
      <div id="main" class="display-container">
        <div></div>
      </div>
      <div class="button-container">
        <t-button shape="round" size="large" theme="success">确定</t-button>
        <t-button @click="graph_continue()" shape="round" size="large" theme="warning">继续</t-button>
        <t-button shape="round" size="large" theme="danger">结束</t-button>
      </div>
    </div>
    <div class="demo-right-container">
      <t-tabs v-model="value" @change="changeTabs">
        <t-tab-panel class="" :value="1" :label="label1" :destroyOnHide="false">
          <div class="resource-graph-check">
            <div class="header-container">
              <t-alert
                v-for="(alert, index) in alerts"
                :key="index"
                :theme="alert.theme"
                :title="alert.title"
                :message="alert.message"
                :close="alert.close"
              >
                <template v-if="!alert.resourceMessage" #operation></template>
                <template v-if="alert.resourceMessage" #message>
                  <span class="alert-create-container">
                    <div class="resource-container" v-for="(resource, idx) in alert.resourceMessage" :key="idx">
                      <div :class="resource.color"></div>
                      <p>{{ resource.name }}</p>
                    </div>
                  </span>
                </template>
              </t-alert>
            </div>
            <div class="content-container" >
              <p v-for="(line, index) in textLines" :key="index" style="padding: 10px; font-size: 1.3em">{{ line }}</p>
            </div>
          </div>
          <div v-if="showButton" style="text-align: right; margin-top: 20px;margin-right: 20px" >
            <t-button @click="startTextTimer()" shape="round" size="large" theme="primary" >解决死锁</t-button>
          </div>
        </t-tab-panel>
        <t-tab-panel :value="2" :label="label2" :destroyOnHide="false">
          <p v-if="!ifSolve" slot="panel" style="padding: 25px">系统执行银行家算法</p>
          <div  v-if="ifSolve" class="resource-graph-check">
            <div class="header-container">
              <t-alert
                v-for="(alert, index) in alerts"
                :key="index"
                :theme="alert.theme"
                :title="alert.title"
                :message="alert.message"
                :close="alert.close"
              >
                <template v-if="!alert.resourceMessage" #operation></template>
                <template v-if="alert.resourceMessage" #message>
                  <span class="alert-create-container">
                    <div class="resource-container" v-for="(resource, idx) in alert.resourceMessage" :key="idx">
                      <div :class="resource.color"></div>
                      <p>{{ resource.name }}</p>
                    </div>
                  </span>
                </template>
              </t-alert>
            </div>
            <div class="content-container" >
              <p v-for="(line, index) in textLines" :key="index" style="padding: 10px; font-size: 1.3em">{{ line }}</p>
            </div>
            <div v-if="showButton" style="text-align: right; margin-top: 20px;margin-right: 20px" >
              <t-button @click="startTextTimer()" shape="round" size="large" theme="primary" >解决死锁</t-button>
            </div>
          </div>
        </t-tab-panel>
      </t-tabs>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts';
import host from '@/config/host';
import {generateBankerData} from './index.js';

export default {
  data() {
    return {
      value: 1,
      alerts: [],
      textLines: [],
      textLines2: [],
      graphData: {},
      bankData: {},
      createData: {},
      createData_need: {},
      graphNode: [],
      edges: [],
      edges_banker: [],
      index: 1,
      showError: false,
      showResource: true,
      ifSolve:false,
      showButton: true,
      myChart: null,
      myChart_banker: null,
      bankerData: [],
      safeSequence: [],
      safeSequenceIndex: 1,
      processedSequence: '',
      alertsData: [],
      label1: '资源分配图法检测',
      label2: '银行家算法检测',
      url: `${host.release.API}/allocate_resources`,
      safe_url: `${host.test.API}/banker`,
      textData: [],
      option_banker: {
        title: {
          text: '银行家算法检测\n',
          left: '40%',
        },
        tooltip: {},
        // top:'40%',
        animationDurationUpdate: 1500,
        animationEasingUpdate: 'quinticInOut',
        graphic: [],
        series: [
          {
            autoCurveness: true,
            // xAxisIndex:2,
            // autoCurveness:[0.2,-0.2],
            animationDuration: 2000,
            emphasis: {
              // focus: 'adjacency',
            },
            type: 'graph',
            zoom: '0.8',
            // layout: 'circular',
            symbolSize: 60,
            roam: true,
            label: {
              show: true,
              fontSize: 16,
            },
            edgeSymbol: ['circle', 'arrow'],
            edgeSymbolSize: [4, 15],
            edgeLabel: {
              fontSize: 20,
            },
            data: null,
            force: {
              repulsion: 50,
              edgeLength: 300,
            },
            // links: [],
            links: this.edges,

            lineStyle: {
              opacity: 0.9,
              width: 4,
              // curveness: 0.2,
            },
          },
        ],
      },
    };
  },
  created() {
    if (this.$route.params.type === 'solve') {
      this.ifSolve = true;
      this.showButton = true;
      this.label1 = '回滚进程';
      this.label2 = '撤销进程';
      this.url = `${host.release.API}/allocate_resources_solve`
      this.safe_url=`${host.release.API}/allocate_resources_solve`
    } else {
      this.ifSolve = false;
      this.showButton = false;
      this.url = `${host.release.API}/allocate_resources`
      this.safe_url= `${host.test.API}/banker`
      this.label1 = '资源分配图法检测';
      this.label2 = '银行家算法检测';
      this.textData = [
        '初始化资源分配图...',
        '资源节点的出边表示已经分走的资源',
        '资源节点的出边表示已经分走的资源，去掉这些资源，简化分配图...',
      ];
    }
  },
  methods: {
    async startAlertTimer() {
      // if (this.$route.params.type === 'check') {
      this.alertsData = [
        {
          theme: 'warning',
          title: '请注意！',
          message: '系统正在执行资源分配图检测算法',
          close: true,
        },
        {
          theme: 'success',
          title: '已成功创建进程1、2、3！',
          close: true,
        },
        {
          theme: 'success',
          title: '已成功创建资源A、B、C！',
          close: true,
          resourceMessage: [
            {name: 'A资源', color: 'blue-circle'},
            {name: 'B资源', color: 'red-circle'},
            {name: 'C资源', color: 'green-circle'},
          ],
        },
      ];
      // }
      const errorAlert = {
        theme: 'error',
        title: '请注意！',
        message: '执行失败',
        close: true,
      };
      let index = 0;
      this.alerts = [];
      this.alerts.push(this.alertsData[index]);
      index++;
      setTimeout(() => {
        if (this.showError) {
          this.alerts.push(errorAlert);
          return;
        }
        console.log(this.showError);

        const interval = setInterval(() => {
          this.alerts.push(this.alertsData[index]);
          index++;
          if (index >= this.alertsData.length) {
            clearInterval(interval);
            this.initCharts();
            // this.startTextTimer();
          }
        }, 1000);
      }, 1500);
    },
    startTextTimer() {
      this.showButton = false;
      let index = 0;
      setTimeout(() => {
        this.graph_continue();
      },1000)
      const dataS = this.ifSolve && this.value === 2 ? this.textLines2 : this.textData;
      const interval = setInterval(() => {
        this.textLines.push(dataS[index]);
        index++;
        if (index >= dataS.length) {
          clearInterval(interval);
        }
      }, 1000);
    },
    graph_continue() {
      echarts.init(document.getElementById('main')).dispose();
      // this.edges.push.apply( this.edges,this.graphData.edges[this.index]);
      this.edges = this.graphData.edges[this.index];
      console.log("edges",this.edges);
      this.index++;
      this.initCharts();
    },
    graph_continue_banker() {
      echarts.init(document.getElementById('main_banker')).dispose();
      this.option_banker.series[0].links = this.edges_banker[this.safeSequence[this.safeSequenceIndex]];
      console.log(this.edges_banker);
      this.safeSequenceIndex++;
      this.initCharts_Banker();
    },
    initCharts() {
      const chartDom = document.getElementById('main');
      const myChart = echarts.init(chartDom);
      this.myChart = myChart;
      const option = {
        title: {
          text: '资源分配图检测',
          left: '43%',
        },
        tooltip: {},
        animationDurationUpdate: 1500,
        animationEasingUpdate: 'quinticInOut',

        series: [
          {
            autoCurveness: true,
            // autoCurveness:[0.2,-0.2],
            animationDuration: 2000,
            emphasis: {
              focus: 'adjacency',
            },
            type: 'graph',
            layout: 'circular',
            symbolSize: 60,
            roam: true,
            label: {
              show: true,
              fontSize: 16,
            },
            edgeSymbol: ['circle', 'arrow'],
            edgeSymbolSize: [4, 15],
            edgeLabel: {
              fontSize: 20,
            },
            data: this.graphNode,
            force: {
              repulsion: 50,
              edgeLength: 300,
            },
            // links: [],
            links: this.edges,
            lineStyle: {
              // color: (params)=> params.data.color,
              // console.log("params",params)
              // // 查找当前链接的目标节点，并获取其颜色
              // const targetN = Number(params.data.target)
              // // eslint-disable-next-line no-nested-ternary
              // const name = targetN ===0 ? '资源A' : targetN ===1 ? '资源B' : targetN ===2 ? '资源C' : '';
              // const targetNode = this.graphNode.find(node => node.name === name);
              // if (targetNode) {
              // 如果找到了目标节点，并且链接数据中有 lineColor 属性，则使用该颜色
              //   return params.data.color || targetNode.itemStyle.color;
              // }
              // // 如果找不到目标节点或链接数据中没有 lineColor 属性，则使用默认颜色
              // return '#4DEE85';
              // source  target
              color:'target',
              opacity: 0.9,
              width: 4,
              // curveness: 0.1
            },
          },
        ],
      };

      myChart.setOption(option);
    },
    async getGraphData() {
      const config = {
        method: 'post',
        url: this.ifSolve && this.value === 1 ? this.safe_url:this.url,
        headers: {
          'Content-Type': 'application/json',
        },
        data: this.ifSolve && this.value === 2 ? this.createData : this.createData_need,
      };
      this.$request(config)
        .then(async (res) => {
          if (res.status === 200) {
            console.log("resData", res.data);
            this.graphData = res.data;
            if (this.$route.params.type === 'solve') {
              this.textData = this.graphData.prints;
              // alertsData
              this.graphData.message.forEach((item) => {
                if (item.num===1){
                  this.alertsData[0].message = item.msg;
                }
              });
            }
            this.graphNode = this.graphData.nodes;
            const typeMappings = {
              Resource: {
                names: ['资源A', '资源B', '资源C'],
                colors: ['#427ff2', '#de2a07', '#73c430'],
              },
              Process: {
                names: ['进程1', '进程2', '进程3'],
                // colors: ['#000000', '#333333', '#666666']
              },
            };
            let isProcess = false;
            let processIndex = 0;
            this.graphNode.forEach((item) => {
              if (typeMappings[item.type]) {
                const index = item.name;
                if (item.type === 'Process') {
                  isProcess = true;
                }
                const typeMapping = typeMappings[item.type];
                if (isProcess) {
                  item.name = typeMapping.names[processIndex++];
                } else {
                  item.name = typeMapping.names[index];
                }

                if (item.type === 'Resource') {
                  item.itemStyle = {color: typeMapping.colors[index]};
                }
              }
            });
            // this.graphData.edges.forEach((item) => {
            //   item.forEach((edge) => {
            //     edge.color = typeMappings.Resource.colors[edge.target];
            //   })
            // })
            this.edges = this.graphData.edges[0]
            console.log("edges1",this.edges)
          }
        })
        .catch((e) => {
          this.showError = true;
          // 分类处理不同类型的错误
          if (e.response) {
            // 请求已发出，服务器作出响应，但返回了非200状态码
            console.error('Server responded with status:', e.response.status);
            if (e.response.status === 400) {
              // 处理客户端错误，例如输入数据有误
              this.$message.warning('输入数据有误，请检查后重新提交。');
            } else if (e.response.status === 500) {
              // 处理服务器内部错误
              this.$message.error('服务器发生错误，请求无法处理。');
            } else {
              // 处理其他服务器错误
              this.$message.warning('服务器返回了非预期的响应。');
            }
          } else if (e.request) {
            // 请求已发出，但没有收到响应
            console.error('Request was made but no response was received:', e.request);
            this.$message.warning('未连接到后端或请求超时，请检查网络连接后重试。');
          } else {
            // 服务器未接收到请求
            console.error('Error making the request:', e.message);
            this.$message.error('请求发送失败，请检查网络连接后重试。');
          }

          // 记录更多的错误上下文信息
          console.error('Request configuration:', config);
        });
    },
    changeTabs(value) {
      this.textLines = [];
      this.initData();
      this.showButton = this.$route.params.type === 'solve';
      if (value === 1 || this.$route.params.type === 'solve') {
        this.showResource = true;
        echarts.init(document.getElementById('main')).dispose();
        setTimeout(() => {
          this.initCharts();
        }, 1000)
      } else {
        this.showResource = false;
        // this.initCharts_Banker();
        echarts.init(document.getElementById('main_banker')).dispose();
        setTimeout(() => {
          this.initCharts_Banker();
        }, 1000)

      }
    },

    initCharts_Banker() {
      const chartDom = document.getElementById('main_banker');
      const myChart = echarts.init(chartDom);
      this.myChart_banker = myChart;
      const option = this.option_banker;
      myChart.setOption(option);
    },
    async getSafeSequence() {
      const config = {
        method: 'post',
        url: this.safe_url,
        headers: {
          'Content-Type': 'application/json',
        },
        data: this.createData,
      };
      this.$request(config)
        .then(async (res) => {
          if (res.status === 200) {
            if (this.$route.params.type === 'solve'){
              this.textLines2 = res.data.prints;
              console.log("textLines2", this.textLines2);
            }else{
              this.safeSequence = res.data.safe_sequence;
              const processedSequence = this.safeSequence.map((number) => `进程${number + 1}`);
              this.option_banker.title.text = '银行家算法检测\n安全序列：' + processedSequence.join('->');
              this.processedSequence = '银行家算法检测\n' + processedSequence.join('->');
            }

          }
        })
        .catch((e) => {
          this.$message.warning('未连接到后端！');
          console.log(e);
        });
    },
    initData() {
      this.createData = JSON.parse(sessionStorage.getItem('data'));
      this.createData_need = JSON.parse(sessionStorage.getItem('data_need'));

      this.getGraphData();
      this.getSafeSequence();
      this.startAlertTimer();

      this.bankerData = generateBankerData();
      this.option_banker.graphic = this.bankerData[0];
      this.option_banker.series[0].data = this.bankerData[1];
      this.option_banker.series[0].links = this.bankerData[2][0];
      this.edges_banker = this.bankerData[2];
      this.option_banker.title.text = this.processedSequence;
    }
  },
  mounted() {
    this.initData();


    // setTimeout(()=>{
    //   this.initCharts_Banker();
    // },1000)

    // console.log(1111,this.edges)
    // this.getBankData()
  },
};
</script>

<style scoped>
.demo-container {
  display: flex;
  justify-content: space-between;
  width: 100%;
  height: 100%;
}

.demo-left-container {
  width: 60%;
  height: 100%;
  background-color: white;
}

.display-container {
  height: 90%;
  width: 100%
}

.demo-right-container {
  width: 37%;
  height: 100%;
  background-color: white;
}

.resource-graph-check {
  width: 100%;
  height: 100%;
}

.header-container {
  width: 100%;
}

.t-alert {
  border: 1px solid lightgray;
}

.alert-create-container {
  display: flex;
}

.resource-container {
  display: flex;
  align-items: center;
  margin-right: 2em;
}

.blue-circle {
  width: 1em;
  height: 1em;
  border-radius: 50%;
  background-color: #427ff2;
}

.red-circle {
  width: 1em;
  height: 1em;
  border-radius: 50%;
  background-color: #de2a07;
}

.green-circle {
  width: 1em;
  height: 1em;
  border-radius: 50%;
  background-color: #73c430;
}

.button-container {
  display: flex;
  justify-content: space-around;
}


</style>
