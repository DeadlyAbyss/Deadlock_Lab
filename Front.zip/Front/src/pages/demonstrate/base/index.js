

export function generateBankerData(){
    const createData = JSON.parse(sessionStorage.getItem('data'));
    var resources = [];
    var processes = [];
    var i=0;
    var returnData = [];
    var nodeData = [];
    var allocationNodeData = [];
    var edgeData = [];
    var resource_in_process_index = [];
    var resource_in_use_index = [];

    for (let i = 0; i < createData.resources.length; i++) {
        resources.push(createData.resources[i]);
    }
    for (let i = 0; i < createData.processes.length; i++) {
        processes.push(createData.processes[i]);
    }

    var graphicData = [];
    for (i = 0; i < processes.length; i++) {
        var data = {
            id:i,
            type:'text',
            top:`${(i+2)*10.5}%`,
            style:{
                text:`进程${i+1}:`,
                font: 'bold 2em sans-serif',
                x:10,
                // y:100*(i+1),
            },
            z: 100,
        }
        graphicData.push(data);
    }
    var data = {
        id:i,
        type:'text',
        top:`${(i+2)*10.8}%`,
        style:{
            text:`空闲资源:`,
            font: 'bold 2em sans-serif',
            x:10,
            // y:100*(i+1),
        },
        z: 100,
    }
    graphicData.push(data);
    returnData.push(graphicData);
    
    const letters = ['A', 'B', 'C'];
    const colors = ['#427ff2', '#de2a07', '#73c430'];

    // 为每个进程分配结点
    // 第一层遍历进程
    for (let i=0; i<processes.length; ++i){
        var process = processes[i];
        var max_req = process.max_requirements;
        //每个进程的结点数
        var nodeNum = 0;
        // 第二层遍历资源
        for (let j=0; j<resources.length; ++j){
            
            // 第三层针对每个资源添加节点
            for(let k=0; k<max_req[j]; ++k,++nodeNum){
                var data = {
                    name:`资源${letters[j]}\n进程${i+1}\n${k+1}`,
                    x:5*(nodeNum+1),
                    y:5*(i+1),
                    itemStyle:{
                        // color:colors[j],
                        color:'#EEEEEE',

                    }
                }
                nodeData.push(data)
            }
        }
    }

    // 为每个进程已分配的资源分配不同颜色
    allocationNodeData = [...nodeData];
    var nodeIndex = 0;
    for(let i=0;i<processes.length;++i){
        var process = processes[i];
        var max_req = [...process.max_requirements];
        var allocations = process.allocation;
        var index = [];
        for(let j = 0;j<resources.length;++j){
            index.push(nodeIndex)
            for(let k=0;k<max_req[j]; ++k,++nodeIndex){
                if(k<allocations[j]){
                    allocationNodeData[nodeIndex].itemStyle.color = colors[j];
                }
                
            }
        }
        resource_in_process_index.push(index);
        
    }
   

    // 为所有资源分配结点
    // 每个资源
    var globalCount=nodeIndex;
    for( let i = 0; i<resources.length; ++i){
        var nodeNum = 0;
        var resource = resources[i];
        var count = resource.count;
        var allocated = processes.reduce((sum, process) => sum + process.allocation[i], 0)
        resource_in_use_index.push(globalCount)
        globalCount+=count;
        // 为每个资源分配结点
        for( let j = 0; j<count; ++j, ++nodeNum){
            var data = {
                name:`资源${letters[i]}\n${j+1}`,
                x:5*(nodeNum+1),
                y:5*(i+4),
                itemStyle:{
                    // color:colors[i],
                    color:(allocated > j)?colors[i]:'#EEEEEE'
                }
            }
            nodeData.push(data)
        }
    }


    returnData.push(nodeData)

    // 定义边
    // 循环进程
    for(let i = 0;i<processes.length;++i){
        //循环资源
        var edge = []
        for(let j=0;j<resources.length;++j){
            var data = {
                source:resource_in_process_index[i][j],
                target:resource_in_use_index[j]
            }
            edge.push(data)
        }
        edgeData.push(edge)
    }
    returnData.push(edgeData)
    console.log('rest',resource_in_use_index)

    return returnData
}