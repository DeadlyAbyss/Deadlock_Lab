<template>
  <div>
    <!-- <t-radio-group defaultValue="1" v-model="value" @change="onChange">
    <t-radio :value="1">资源分配图法检测</t-radio>
    <t-radio :value="2">银行家算法检测</t-radio>
  </t-radio-group> -->
    <t-tabs v-model="value2">
      <t-tab-panel :value="1" label="资源分配图法检测">
        <div class="analyze-detail-container">
          <div class="analze-detail-content-container">
            <div class="detail-left">
              <p>此场景下，</p>
              <p>
                死锁频率为
                <t-input-number
                  :format="(value, { fixedNumber }) => `${fixedNumber} %`"
                  align="center"
                  :decimalPlaces="2"
                  theme="normal"
                  autoWidth
                  @change="onChange"
                ></t-input-number>
              </p>
              <p>
                资源利用率为
                <t-input-number
                  :format="(value, { fixedNumber }) => `${fixedNumber} %`"
                  align="center"
                  :decimalPlaces="2"
                  theme="normal"
                  autoWidth
                  @change="onChange"
                ></t-input-number>
              </p>
              <p>
                进程调度总次数为
                <t-input-number  align="center" theme="normal" autoWidth @change="onChange">
                </t-input-number>
                次
              </p>
              <!-- <p>
                进程A的高响应比为
                <t-input-number
                  align="center"
                  :decimalPlaces="2"
                  theme="normal"
                  autoWidth
                  @change="onChange"
                ></t-input-number>
              </p>
              <p>
                进程B的高响应比为
                <t-input-number
                  align="center"
                  :decimalPlaces="2"
                  theme="normal"
                  autoWidth
                  @change="onChange"
                ></t-input-number>
              </p> -->
            </div>
            <div v-if="showSystemAnalyze" class="detail-right">
              <p>此场景下，</p>
              <p>死锁频率为 {{ analysis.deadlock_frequency }} %</p>
              <p>资源利用率为 {{ resource_utilization }} %</p>
              <p>进程调度总次数为 {{ analysis.total_scheduling_operations }} 次</p>
              <!-- <p>进程A的高响应比为</p>
              <p>进程B的高响应比为</p> -->
            </div>
          </div>
        </div>
        <div class="analze-button-container">
          <t-button theme="primary" size="large" variant="base" @click="analyze()">系统分析</t-button>
        </div>
      </t-tab-panel>
      <t-tab-panel :value="2" label="银行家算法检测">
        <div class="analyze-detail-container">
          <div class="analze-detail-content-container">
            <div class="detail-left">
              <p>此场景下，</p>
              <p>
                死锁频率为
                <t-input-number
                  :format="(value, { fixedNumber }) => `${fixedNumber} %`"

                  align="center"
                  :decimalPlaces="2"
                  theme="normal"
                  autoWidth
                  @change="onChange"
                ></t-input-number>
              </p>
              <p>
                资源利用率为
                <t-input-number
                  :format="(value, { fixedNumber }) => `${fixedNumber} %`"

                  align="center"
                  :decimalPlaces="2"
                  theme="normal"
                  autoWidth
                  @change="onChange"
                ></t-input-number>
              </p>
              <p>
                进程调度总次数为
                <t-input-number align="center" theme="normal" autoWidth @change="onChange">
                </t-input-number>
                次
              </p>
              <!-- <p>
                进程A的高响应比为
                <t-input-number

                  align="center"
                  :decimalPlaces="2"
                  theme="normal"
                  autoWidth
                  @change="onChange"
                ></t-input-number>
              </p>
              <p>
                进程B的高响应比为
                <t-input-number

                  align="center"
                  :decimalPlaces="2"
                  theme="normal"
                  autoWidth
                  @change="onChange"
                ></t-input-number>
              </p> -->
            </div>
            <div v-if="showSystemAnalyze2" class="detail-right">
              <p>此场景下，</p>
              <p>死锁频率为 {{ analysis.deadlock_frequency }} %</p>
              <p>资源利用率为 {{ resource_utilization }} %</p>
              <p>进程调度总次数为 {{ analysis.total_scheduling_operations }} 次</p>
              <!-- <p>进程A的高响应比为</p>
              <p>进程B的高响应比为</p> -->
            </div>
          </div>
        </div>
        <div class="analze-button-container">
          <t-button theme="primary" size="large" variant="base" @click="analyze2()">系统分析</t-button>
        </div>
      </t-tab-panel>
    </t-tabs>
  </div>
</template>

<script>
import host from "@/config/host";
export default {
  data() {
    return {
      value: 1,
      value2: 1,
      value3: 1,
      showSystemAnalyze: false,
      showSystemAnalyze2:false,
      data:{}
    };
  },
  computed:{
    resource_utilization(){
      return this.analysis.resource_utilization.reduce((acc, curr) => acc + curr, 0)/this.analysis.resource_utilization.length
    }
  },
  methods: {
    onChange() {
      console.log(this.value);
    },
    analyze() {
      this.showSystemAnalyze = true;
    },
    analyze2() {
      this.showSystemAnalyze2 = true;
    },
    onSubmit() {



        const config = {
          method: 'post',
          url: `${host.test.API}/banker`,
          headers: {
            'Content-Type': 'application/json',
          },
          data: this.data
        };
        this.$request(config)
          .then(async (res) => {
            if (res.status === 200) {
              console.log(res.data)
              this.analysis = res.data;
            }
          })
          .catch((e) => {
            this.$message.warning('未连接到后端！');
            console.log(e)
          });


      }
    },
  mounted(){
    const data = sessionStorage.getItem('data');
    this.data = data;
    console.log(data);
    this.onSubmit()
  }
};
</script>

<style scoped>
.analze-detail-content-container {
  margin: 60px;
  display: flex;
  justify-content: space-around;
  font-size: large;
  line-height: 2em;
}
.analze-button-container {
  display: flex;
  justify-content: center;
  margin-bottom: 5em;
}
</style>
