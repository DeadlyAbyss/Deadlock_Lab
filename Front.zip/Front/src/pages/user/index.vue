<template>
  <t-row :gutter="[16, 16]">
    <t-col :flex="3">
      <div class="user-left-greeting">
        <div>
          Hi，{{ username }}
          <span class="regular"> 你好，现在是{{ datetime }}～</span>
        </div>
      </div>

      <t-card class="user-info-list" title="个人信息" :bordered="false">
        <template #option>
          <t-button theme="default" shape="square" variant="text">
            <edit-icon size="18" />
          </t-button>
        </template>
        <t-row class="content" justify="space-between">
          <t-col v-for="(item, index) in USER_INFO_LIST" :key="index" class="contract" :span="item.span || 3">
            <div class="contract-title">
              {{ item.title }}
            </div>
            <div class="contract-detail">
              {{ item.content }}
            </div>
          </t-col>
        </t-row>
      </t-card>
    </t-col>

    <t-col :flex="1">
      <t-card class="user-intro" :bordered="false">
        <t-avatar size="90px">{{ username.slice(0,1) }}</t-avatar>
        <div class="name">{{ username }}</div>
        <div class="position">XXXXXXXXXXXXXX</div>
      </t-card>

    </t-col>
  </t-row>
</template>
<script>


import { LAST_7_DAYS } from '@/utils/date';

import { USER_INFO_LIST, TEAM_MEMBERS, PRODUCT_LIST } from '@/service/service-user';



export default {
  name: 'UserIndex',


  data() {
    return {

      LAST_7_DAYS,
      USER_INFO_LIST,

      datetime:null,
      username:'Student'
    };
  },

  mounted() {
    this.updateTime();
    // 每隔一秒更新一次时间
    setInterval(this.updateTime, 1000);
    this.username = sessionStorage.getItem('username');
  },
  methods: {
    updateTime() {
      var d = new Date();
      this.datetime = d.toLocaleString();
    }
  }
};
</script>
<style lang="less" scoped>
@import url('./index.less');
</style>
