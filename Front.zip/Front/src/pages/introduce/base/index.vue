<template>
  <div class="backgrond">
    <div class="introduce-container">
      <div class="introduce-title">平台介绍</div>
      <div class="introduce-content">
        <p>
          操作系统死锁实验平台为用户提供了一个<strong>模拟操作系统死锁场景</strong>的环境，通过模拟进程之间的资源竞争和调度情况，帮助用户深入理解死锁的产生机制、检测方法以及解决策略。通过实验平台，用户可以模拟不同的死锁情景，观察死锁的发生条件和影响，进而探索如何有效地预防和解决死锁问题。
        </p>
        <p>
          本实验平台提供多种不同类型的实验场景，涵盖了常见的<strong>死锁情况</strong>和<strong>解决策略</strong>，如<strong>资源分配图、银行家算法</strong>等。用户可以根据自己的需求选择合适的实验场景进行模拟和探索，从而全面了解死锁问题的本质和解决方法。同时，用户也可以<strong>灵活设置实验参数</strong>，包括<strong>进程数量、资源数量、资源类型</strong>，以模拟不同的实验场景和情况。通过调整参数，可以观察到不同参数对死锁发生的影响，深入理解死锁问题的产生机制。
        </p>
        <p>
          建立虚拟仿真实验教学平台，可以作为<strong>教学工具</strong>共享教学实验资源，帮助学生更好地理解操作系统中的死锁问题，深入死锁问题的本质，加深对操作系统原理的理解，为教师和学生提供参考和指导。
        </p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.backgrond {
  margin: -24px -24px;
  width: calc(100% + 48px);
  height: calc(100% + 48px);
  background-image: url('@/assets/breathe-top.png');
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: center;
  align-items: center;
}
.introduce-container {
  padding: 2em;
  font-size: 1.5em;
  width: 1000px;
  height: 600px;
  min-width: 800px;
  background-color: white;

  border-radius: 10px;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}
.introduce-title {
  text-align: center;
  font-size: 1.2em;
}
.introduce-content {
  text-indent: 2em;
  margin-top: 2em;
  line-height: 170%;
}
</style>
<script>
</script>
