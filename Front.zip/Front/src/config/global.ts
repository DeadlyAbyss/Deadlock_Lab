export const prefix = 'tdesign-starter';
export const TOKEN_NAME = 'tdesign-starter';
